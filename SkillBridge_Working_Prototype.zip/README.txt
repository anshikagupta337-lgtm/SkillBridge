# SkillBridge Hackathon Prototype
## Run it
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. Click **Find My Match**, select skills and press **Find matches**.
4. Try **Skill Roadmap** and **Opportunities**.
No installation, internet connection, account, or API key is required.

## What is included
- Responsive student career dashboard
- Rule-based skill matching and percentage score
- Missing-skill checker
- Beginner learning roadmap
- Searchable sample internship/project listings
- Sample profile button for a quick demo

## Important
This is a front-end hackathon prototype. Listings and matching are sample/demo data; it is not connected to live vacancies or a real employer database. Do not enter sensitive personal data.
